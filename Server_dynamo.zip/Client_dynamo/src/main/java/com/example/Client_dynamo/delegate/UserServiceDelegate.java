package com.example.Client_dynamo.delegate;

import com.example.Client_dynamo.dto.*;
import com.example.Client_dynamo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserServiceDelegate {

    @Autowired
    private UserService userService;

    public RegistrationResponseDTO registerUser(RegistrationRequestDTO requestDTO) {
        return userService.registerUser(requestDTO);
    }

    public LoginResponseDTO loginUser(LoginRequestDTO requestDTO) {
        return userService.loginUser(requestDTO);
    }
}
