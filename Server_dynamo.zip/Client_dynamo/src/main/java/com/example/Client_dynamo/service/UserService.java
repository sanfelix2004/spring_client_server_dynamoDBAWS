package com.example.Client_dynamo.service;

import com.example.Client_dynamo.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserService {

    @Autowired
    private RestTemplate restTemplate;

    private final String serverUrl = "http://localhost:8889/users";

    public RegistrationResponseDTO registerUser(RegistrationRequestDTO requestDTO) {
        return restTemplate.postForObject(serverUrl + "/register", requestDTO, RegistrationResponseDTO.class);
    }

    public LoginResponseDTO loginUser(LoginRequestDTO requestDTO) {
        return restTemplate.postForObject(serverUrl + "/login", requestDTO, LoginResponseDTO.class);
    }
}
