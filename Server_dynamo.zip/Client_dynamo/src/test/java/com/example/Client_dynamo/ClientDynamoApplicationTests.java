package com.example.Client_dynamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientDynamoApplicationTests {

	@Test
	void contextLoads() {
	}

}
