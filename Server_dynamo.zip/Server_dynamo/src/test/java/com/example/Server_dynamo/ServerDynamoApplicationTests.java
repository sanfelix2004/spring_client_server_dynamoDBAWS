package com.example.Server_dynamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerDynamoApplicationTests {

	@Test
	void contextLoads() {
	}

}
