package com.example.Server_dynamo;

import com.example.Server_dynamo.config.DynamoDBInitializer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableConfigServer
public class ServerDynamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerDynamoApplication.class, args);
	}

	@Bean
	CommandLineRunner initializeDynamoDB(DynamoDBInitializer dynamoDBInitializer) {
		return args -> {
			System.out.println("Esecuzione dell'inizializzazione di DynamoDB...");
		};
	}

}
