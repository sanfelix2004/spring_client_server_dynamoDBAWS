package com.example.Server_dynamo.controller;

import com.example.Server_dynamo.dto.*;
import com.example.Server_dynamo.delegate.UserServiceDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserServiceDelegate userServiceDelegate;


    @PostMapping("/register")
    public ResponseEntity<RegistrationResponseDTO> registerUser(@RequestBody RegistrationRequestDTO requestDTO) {
        RegistrationResponseDTO response = userServiceDelegate.registerUser(requestDTO);
        return ResponseEntity.ok(response);
    }


    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> loginUser(@RequestBody LoginRequestDTO requestDTO) {
        LoginResponseDTO response = userServiceDelegate.loginUser(requestDTO);
        return ResponseEntity.ok(response);
    }
}
