package com.example.Server_dynamo.config;

import org.springframework.stereotype.Component;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.util.List;

@Component
public class DynamoDBInitializer {

    private final DynamoDbClient dynamoDbClient;

    public DynamoDBInitializer(DynamoDbClient dynamoDbClient) {
        this.dynamoDbClient = dynamoDbClient;
        clearAllTables();
        initializeUserTable();
    }

    private void clearAllTables() {
        ListTablesResponse listTablesResponse = dynamoDbClient.listTables();

        List<String> tableNames = listTablesResponse.tableNames();
        if (!tableNames.isEmpty()) {
            for (String tableName : tableNames) {
                try {
                    dynamoDbClient.deleteTable(DeleteTableRequest.builder().tableName(tableName).build());
                    System.out.println("Tabella '" + tableName + "' eliminata con successo.");
                } catch (Exception e) {
                    System.err.println("Errore durante l'eliminazione della tabella '" + tableName + "': " + e.getMessage());
                }
            }
        } else {
            System.out.println("Nessuna tabella trovata per essere eliminata.");
        }
    }

    private void initializeUserTable() {
        String tableName = "Users";

        try {
            dynamoDbClient.describeTable(
                    DescribeTableRequest.builder().tableName(tableName).build()
            );
            System.out.println("La tabella '" + tableName + "' esiste già.");
        } catch (ResourceNotFoundException e) {
            createTable(tableName);
        }
    }

    private void createTable(String tableName) {
        CreateTableRequest createTableRequest = CreateTableRequest.builder()
                .tableName(tableName)
                .keySchema(
                        KeySchemaElement.builder()
                                .attributeName("email") // Chiave primaria
                                .keyType(KeyType.HASH)
                                .build()
                )
                .attributeDefinitions(
                        AttributeDefinition.builder()
                                .attributeName("email")
                                .attributeType(ScalarAttributeType.S)
                                .build()
                )
                .billingMode(BillingMode.PAY_PER_REQUEST)
                .build();

        dynamoDbClient.createTable(createTableRequest);
        System.out.println("Tabella '" + tableName + "' creata con successo con gli attributi email (chiave primaria).");
    }

}
