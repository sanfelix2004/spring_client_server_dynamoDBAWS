package com.example.Server_dynamo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
public class ConfigServerConfig {
    //configurazioni o Bean extra
}
