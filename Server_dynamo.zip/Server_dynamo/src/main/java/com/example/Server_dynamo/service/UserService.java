package com.example.Server_dynamo.service;

import com.example.Server_dynamo.dto.*;
import com.example.Server_dynamo.delegate.UserRepositoryDelegate;
import com.example.Server_dynamo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepositoryDelegate userRepositoryDelegate;

    public RegistrationResponseDTO registerUser(RegistrationRequestDTO requestDTO) {
        String id = UUID.randomUUID().toString();
        User user = new User(id, requestDTO.getName(), requestDTO.getEmail(), requestDTO.getPassword());
        userRepositoryDelegate.saveUser(user);
        return new RegistrationResponseDTO("Utente registrato con successo!");
    }

    public LoginResponseDTO loginUser(LoginRequestDTO requestDTO) {
        User user = userRepositoryDelegate.findUserByEmail(requestDTO.getEmail());
        if (user != null && user.getPassword().equals(requestDTO.getPassword())) {
            return new LoginResponseDTO("Login effettuato con successo!");
        }
        return new LoginResponseDTO("Credenziali errate.");
    }
}
