package com.example.Server_dynamo.repository;

import com.example.Server_dynamo.model.User;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class UserRepository {

    private Map<String, User> userStore = new HashMap<>();

    public void save(User user) {
        userStore.put(user.getEmail(), user);
    }

    public User findByEmail(String email) {
        return userStore.get(email);
    }
}
